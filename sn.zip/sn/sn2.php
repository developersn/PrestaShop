<?php

session_start();
if (isset($_GET['do'])) {
	include (dirname(__FILE__) . '/../../config/config.inc.php');
	include (dirname(__FILE__) . '/../../header.php');
	include_once (dirname(__FILE__) . '/sn.php');
	$sn = new sn;

	if ($_GET['do'] == 'payment') {

			$sn -> do_payment($cart);

	} else {
		if (isset($_GET['sec']) && isset($_GET['md'])) {
		// Security
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');
$mdurl=$_GET['md'];
// Security		
				if($mdback == $mdurl){
			
		
$transData = $_SESSION[$sec];
$au=$transData['au']; //


			$orderId = $_GET['order_id'];
			$amount = $transData['price'];
			$au=$transData['au'];
			if (isset($_GET['order_id'])) {
				
				
					$api = Configuration::get('sn_API');
					
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $api,
'price' => $amount/10,
'order_id' => $orderId,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);
					if (!empty($json['result']) and $json['result'] == 1) {
						error_reporting(E_ALL);
						
						$sn -> validateOrder($orderId, _PS_OS_PAYMENT_, $amount, $sn -> displayName, "سفارش تایید شده / کد رهگیری {$au}", array(), $cookie -> id_currency);
						$orderId = '';
						Tools::redirect('history.php');
					} else {
						echo $sn -> error($sn -> l('There is a problem.') . ' (' . $json['result'] . ')<br/>' . $sn -> l('Authority code') . ' : ' . $au);
					}

				
			} else {
				echo $sn -> error($sn -> l('There is a problem.'));
			}
		} else {
			echo $sn -> error($sn -> l('There is a problem.'));
		}
				} else {
			echo $sn -> error($sn -> l('There is a problem.'));
		}
	}
	include_once (dirname(__FILE__) . '/../../footer.php');
} else {
	_403();
}
function _403() {
	header('Status: 403 Forbidden');
	header('HTTP/1.1 403 Forbidden');
	exit();
}