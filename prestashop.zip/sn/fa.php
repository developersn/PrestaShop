﻿<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{sn}default>sn_6f45efeb44e5d8cfe1e14ce4467f1f67'] = 'افزونه پرداخت درگاه آنلاین';
$_MODULE['<{sn}default>sn_909b1fcb6b37b6a330444235bfc2462c'] = ' پرداخت آنلاین با درگاه  درگاه آنلاین';
$_MODULE['<{sn}default>sn_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'آیا برای پاک کردن اطلاعات مطمئن هستید؟';
$_MODULE['<{sn}default>sn_e2d93539acef2afbbadf8542351fb2b4'] = 'استفاده از ارز برای این ماژول غیر فعال هست.';
$_MODULE['<{sn}default>sn_6577035ab365dbb6b8f79829d4d29748'] = 'شما برای استفاده از درگاه  درگاه آنلاین می بایست مرچنت کد درگاه خود را در تنظیمات ماژول وارد کنید.';
$_MODULE['<{sn}default>sn_c888438d14855d7d96a2724ee9c306bd'] = 'تنظیمات دخیره شد.';
$_MODULE['<{sn}default>sn_b4740c9e4dd0751ea682fd81d627dee2'] = 'مرچنت کد درگاه خود را وارد نمایید :';
$_MODULE['<{sn}default>sn_17857bb7e0e4a22fa99900af223a03f9'] = 'ذخیره کن!';
$_MODULE['<{sn}default>sn_6585d9032a8dc4539e89237937549739'] = 'مشکلی وجود دارد!';
$_MODULE['<{sn}default>sn_2ea624d388b73c5ad7976bbb9d758a4f'] = 'در حال انتقال ...';
$_MODULE['<{sn}default>jppayment_a9950f28d15992aed5045f5818cdb361'] = ' پرداخت آنلاین با درگاه  درگاه آنلاین';
